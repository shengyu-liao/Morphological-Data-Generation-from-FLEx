#
#   LookupReadConfig
#   Values for reading a Lookup configuration file
#
#   Modified:      27 Sep 2022    bb     v3.5.7 Adjust to work along with FLExTrans or separately
#
#   Version 3.5.6 - 02 Aug 2022 - BB    First version
#   Beth Bryson
#   SIL International


import re
import os
import unicodedata

from FTPaths import CONFIG_PATH

## Name of the config file
LOOKUP_CONFIG_FILE = 'Lookup.config'
## Overwrite what was set by ReadConfig.py
#CONFIG_FILE = 'Lookup.config'

## -----Delete? ----------
#ANALYZED_TEXT_FILE = 'AnalyzedTextOutputFile'
#ANALYZED_TREETRAN_TEXT_FILE = 'AnalyzedTextTreeTranOutputFile'
#BILINGUAL_DICTIONARY_FILE = 'BilingualDictOutputFile'
#BILINGUAL_DICT_REPLACEMENT_FILE = 'BilingualDictReplacementFile'
#CATEGORY_ABBREV_SUB_LIST = 'CategoryAbbrevSubstitutionList'
#CACHE_DATA = 'CacheData'           # See below
#CLEANUP_UNKNOWN_WORDS = 'CleanUpUnknownTargetWords'           # See below
#SENTENCE_PUNCTUATION = 'SentencePunctuation'           # See below
#SOURCE_COMPLEX_TYPES = 'SourceComplexTypes'
#SOURCE_CUSTOM_FIELD_ENTRY = 'SourceCustomFieldForEntryLink'
#SOURCE_CUSTOM_FIELD_SENSE_NUM = 'SourceCustomFieldForSenseNum'
#SOURCE_DISCONTIG_TYPES = 'SourceDiscontigousComplexTypes'
#SOURCE_DISCONTIG_SKIPPED = 'SourceDiscontigousComplexFormSkippedWordGrammaticalCategories'
#SOURCE_MORPHNAMES = 'SourceMorphNamesCountedAsRoots'        # Needed?
#SOURCE_TEXT_NAME = 'SourceTextName'
#TARGET_AFFIX_GLOSS_FILE = 'TargetAffixGlossListFile'
#TARGET_ANA_FILE = 'TargetOutputANAFile'
#TARGET_FORMS_INFLECTION_1ST = 'TargetComplexFormsWithInflectionOn1stElement'
#TARGET_FORMS_INFLECTION_2ND = 'TargetComplexFormsWithInflectionOn2ndElement'
#TARGET_LEXICON_FILES_FOLDER = 'TargetLexiconFilesFolder'
#TARGET_MORPHNAMES = 'TargetMorphNamesCountedAsRoots'
TARGET_PROJECT = 'TargetProject'       # Needed?
#TARGET_SYNTHESIS_FILE = 'TargetOutputSynthesisFile'
#TESTBED_FILE = 'TestbedFile'
#TESTBED_RESULTS_FILE = 'TestbedResultsFile'
#TRANSFER_RESULTS_FILE = 'TargetTranferResultsFile'
#TRANSFER_RULES_FILE = 'TransferRulesFile'
#TREETRAN_INSERT_WORDS_FILE = 'TreeTranInsertWordsFile'
#TREETRAN_RULES_FILE = 'TreeTranRulesFile'
#

# --------------- Custom for the Lookup Collection -----------------------------

## Name of the config file
#LOOKUP_CONFIG_FILE = 'Lookup.config'
## Overwrite what was set by ReadConfig.py
#CONFIG_FILE = 'Lookup.config'

# Target text to process
TARGET_TEXT_NAME = 'TargetTextName'

## Files to open
# Logfile from the Lookup process
LOOKUP_LOG_FILE = 'LookupLogFile'

# Which morph types to use as roots
TARGET_MORPHNAMES = 'TargetMorphNamesCountedAsRoots'

# Where to put the intermediate files
TARGET_LEXICON_FILES_FOLDER = 'TargetLexiconFilesFolder'

# Generated word parses, in .ana format, for input to STAMP
LOOKUP_ANALYZED_FILE = 'LookupAnalyzedOutputFile'

# Synthesized words file (surface forms)
LOOKUP_SYNTHESIZED_FILE = 'LookupSynthesizedOutputFile'

# Output in human readable format, with glosses of roots and affixes
LOOKUP_PARSES_FILE = 'LookupParsesOutputFile'

# Output in SIGMORPHON format
LOOKUP_SIGMORPHON_FILE = 'LookupSigmorphonOutputFile'

## Settings to limit which words will be processed
## These can be used in combination.

# Only process the first N stems encountered in the database
# Use a digit here.  Often this might be in the range of 1-10, for testing purposes.
LIMIT_STEMCOUNT = 'LimitStemCount'

# Only process stems of this POS
#LimitPOS=Noun
LIMIT_POS = 'LimitPOS'

# Only process this Lexeme Form (can we do multiple?  Not at the moment.)
LIMIT_LEX = 'LimitLex'


## Miscellaneous settings

# Require FlexTools to reload the dictionaries every time?
CACHE_DATA = 'CacheData'

# Indicates if the system should remove preceding @ signs
# and numbers in the form N.N following words in the target text.
# Leaving these marks in, provides a way to find and delete these words 
# from the generated data, if they are not desired in that output.
CLEANUP_UNKNOWN_WORDS = 'CleanUpUnknownTargetWords'

# Only needed if processing texts
SENTENCE_PUNCTUATION = 'SentencePunctuation'

## ------------------------
## Needed for backwards compatibility
#
#LOOKUP_DIS_COMPLEX_TYPES = 'SourceDiscontiguousComplexTypes'
#
# ------------------------ End of custom section -----------------------------------------------------------


def lookupReadConfig(report):
    try:
        # CONFIG_PATH holds the full path to the flextools.ini file which should be in the WorkProjects/xyz/Config folder. That's where we find FLExTools.config
        # Get the parent folder of flextools.ini, i.e. Config and add FLExTools.config
        myPath = os.path.join(os.path.dirname(CONFIG_PATH), LOOKUP_CONFIG_FILE)
        
        f_handle = open(myPath, encoding='utf-8')
    except:
        if report is not None:
            report.Error('Error reading the file: "' + CONFIG_PATH+ '/' + LOOKUP_CONFIG_FILE + '". Check that it exists.')
        return None

    my_map = {}
    for line in f_handle:
        
        # decompose any composed characters. FLEx stores strings this way.
        line = unicodedata.normalize('NFD', line)
        if len(line) < 2:
            if report is not None:
                report.Error('Error reading the file: "' + LOOKUP_CONFIG_FILE + '". No blank lines allowed.')
            return
        # Skip commented lines
        if line[0] == '#':
            continue
        # We expect lines in the form -- property=value
        if not re.search('=', line):
            if report is not None:
                report.Error('Error reading the file: "' + LOOKUP_CONFIG_FILE + '". A line without "=" was found.')
            return
        (prop, value) = line.split('=')
        value = value.rstrip()
        # if the value has commas, save it as a list
        if re.search(',', value):
            my_list = value.split(',')
            my_map[prop] = my_list
        else:
            my_map[prop] = value

    return my_map

# These are the same as in from the real ReadConfig.py
# (Do I need a copy in the Lookup directory?? 
# For now I gave these new names.)
def getConfigValue(my_map, key, report, giveError=True):
    if key not in my_map:
        if report is not None:
            if giveError:
                report.Error('Error in the file: "' + LOOKUP_CONFIG_FILE + '". A value for "'+key+'" was not found.')
        return None
    else:
        # If the key value ends with 'File' then change the path accordingly.
        # Also the key must have a value, otherwise ignore it.
        if (re.search('File$', key) or re.search('Folder$', key)) and key in my_map and my_map[key]:
            
            # if we don't have an absolute path (e.g. c:\...) we need to fix up the path. FLExTrans is shipped with relative paths to the work project subfolder ('e.g. German-Swedish')
            if not re.search(':', my_map[key]):
                
                # Return the parent folder of the Config folder + the relative file path. E.g. ...\German-Swedish\target_text.aper
                return os.path.join(os.path.dirname(os.path.dirname(CONFIG_PATH)), my_map[key])
      
        return my_map[key]

def configValuesList(my_map, key, report):
    if isinstance(my_map[key], list) is False:
        if report is not None:
            report.Error('Error in the file: "' + LOOKUP_CONFIG_FILE + '". The value for "'+key+'" is supposed to be a comma separated list. For a single value, end it with a comma.')
        return False
    else:
        return True

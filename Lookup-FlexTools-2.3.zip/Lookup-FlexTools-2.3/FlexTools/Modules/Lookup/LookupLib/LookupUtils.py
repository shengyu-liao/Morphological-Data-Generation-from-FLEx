#
#   LookupUtils.py
#   Selected functions from FLExTrans/Utils.py.  Originally forked at v3.6.9,
#   but subsequent improvements have been merged in, as noted in the history.
#
#
#   Version 3.7.9 - 5 Jan 2023   - Ron Lockwood   Support fixes to issue 229 by adding a parameter 
#                                               to check_for_cat_errors.
#
#   Version 3.7.7 - 24 Dec 2022 - Ron Lockwood   added GetEntryWithSense, renamed old one to 
#                                               GetEntryWithSensePlusFeat (used in getInterlinData(), not included
#                                               in this subset)
#
#   Version 3.7.3 - 12 Dec 2022  - Ron Lockwood   added none headword constant.
#
#   Version 3.6.9 - 27 Sep 2022 - Beth Bryson   Created LookupUtils.py by forking from 
#                                                Utils.py v3.6.9 in the FLExTrans installation.
#
#   Ron Lockwood
#   SIL International
#   23 Jul 2014
#
#   Shared functions

import re
import tempfile
import os
import shutil
import xml.etree.ElementTree as ET
import subprocess
import unicodedata
from datetime import datetime
from System import Guid
from System import String

from SIL.LCModel import *
from SIL.LCModel.Core.KernelInterfaces import ITsString, ITsStrBldr   
from SIL.LCModel.DomainServices import SegmentServices
from flexlibs import FLExProject, AllProjectNames

#import ReadConfig as MyReadConfig 
import LookupReadConfig as MyLookupReadConfig 
from FTPaths import CONFIG_PATH

NONE_HEADWORD = '**none**'

MAKEFILE_DICT_VARIABLE = 'DICTIONARY_PATH'
MAKEFILE_SOURCE_VARIABLE = 'SOURCE_PATH'
MAKEFILE_TARGET_VARIABLE = 'TARGET_PATH'
MAKEFILE_FLEXTOOLS_VARIABLE = 'FLEXTOOLS_PATH'
CONVERSION_TO_STAMP_CACHE_FILE = 'conversion_to_STAMP_cache.txt'

# File and folder names
OUTPUT_FOLDER = 'Output'
BUILD_FOLDER = 'Build'

# precompiled reguglar expressions
reDataStream = re.compile('(>[^$<])')  
reObjAddOne = re.compile('\d$', re.RegexFlag.A) # ASCII-only match
reTestID = re.compile('test id=".+?"')
reSpace = re.compile(r'\s') 
rePeriod = re.compile(r'\.') 
reForwardSlash = re.compile(r'/') 
reHyphen = re.compile(r'-') 
reAsterisk = re.compile(r'\*') 
# the key is to find non-left or right angle brackets for the alphanumeric parts of the symbol
reSlashInSymbol = re.compile(r'(="[^<>=]+?)(/)([^<>=]+?")')
reSLASHInSymbol = re.compile(r'(<[^<>]+?)SLASH([^<>]+?>)')
reDoubleNewline = re.compile(r'\n\n')

morphTypeMap = {
"d7f713e4-e8cf-11d3-9764-00c04f186933": "bound root",
"d7f713e7-e8cf-11d3-9764-00c04f186933": "bound stem",
"d7f713df-e8cf-11d3-9764-00c04f186933": "circumfix",
"c2d140e5-7ca9-41f4-a69a-22fc7049dd2c": "clitic",
"0cc8c35a-cee9-434d-be58-5d29130fba5b": "discontiguous phrase",
"d7f713e1-e8cf-11d3-9764-00c04f186933": "enclitic",
"d7f713da-e8cf-11d3-9764-00c04f186933": "infix",
"18d9b1c3-b5b6-4c07-b92c-2fe1d2281bd4": "infixing interfix",
"56db04bf-3d58-44cc-b292-4c8aa68538f4": "particle",
"a23b6faa-1052-4f4d-984b-4b338bdaf95f": "phrase",
"d7f713db-e8cf-11d3-9764-00c04f186933": "prefix",
"af6537b0-7175-4387-ba6a-36547d37fb13": "prefixing interfix",
"d7f713e2-e8cf-11d3-9764-00c04f186933": "proclitic",
"d7f713e5-e8cf-11d3-9764-00c04f186933": "root",
"d7f713e8-e8cf-11d3-9764-00c04f186933": "stem",
"d7f713dd-e8cf-11d3-9764-00c04f186933": "suffix",
"3433683d-08a9-4bae-ae53-2a7798f64068": "suffixing interfix"} 

# Invalid category characters & descriptions & messages & replacements
catProbData = [['space', 'converted to an underscore', '_', reSpace],
           ['period', 'removed', '', rePeriod],
           ['slash', 'converted to a vertical bar', '|', reForwardSlash]
#          ['x char', 'fatal', '']
          ]

lemmaProbData = [['asterisk', 'converted to an underscore', '_', reAsterisk]
            ]
                        

def convertProblemChars(convertStr, problemDataList):                                                

    # Convert spaces to underscores and remove periods and convert slash to bar, etc.
    for probDataRow in problemDataList:
        
        # 3 = the compiled RE, 2 = the string to replace with
        convertStr = probDataRow[3].sub(probDataRow[2], convertStr)
        
    return convertStr

def isClitic(myEntry):
    
    return isProclitic(myEntry) or isEnclitic(myEntry)

def isProclitic(entry):
    
    ret_val = False
    
    # What might be passed in for a component could be a sense which isn't a clitic
    if entry.ClassName == 'LexEntry' and entry.LexemeFormOA and entry.LexemeFormOA.MorphTypeRA:
        
        morphGuidStr = entry.LexemeFormOA.MorphTypeRA.Guid.ToString()
        morphType = morphTypeMap[morphGuidStr]
        
        if morphType  == 'proclitic':
        
            ret_val = True
            
    return ret_val
    
def isEnclitic(entry):

    ret_val = False
    
    # What might be passed in for a component could be a sense which isn't a clitic
    if entry.ClassName == 'LexEntry' and entry.LexemeFormOA and entry.LexemeFormOA.MorphTypeRA:
        
        morphGuidStr = entry.LexemeFormOA.MorphTypeRA.Guid.ToString()
        morphType = morphTypeMap[morphGuidStr]
        
        if morphType  == 'enclitic':
        
            ret_val = True
            
    return ret_val

# If the given path is has any relative or full paths
# I.e. there is a slash somewhere, then don't use the
# temp folder. Otherwise use the temp folder.
def build_path_default_to_temp(config_path):    
    # Check for a slash
    if '/' in config_path or '\\' in config_path:
        ret_path = config_path
    else:
        ret_path = os.path.join(tempfile.gettempdir(), config_path)
    return ret_path

# Append '1' to the headWord if there is no homograph #
def add_one(headWord): 
    if not reObjAddOne.search(headWord):
        return (headWord + '1')
    return headWord 

def get_feat_abbr_list(SpecsOC, feat_abbr_list):
    
    for spec in SpecsOC:
        if spec.ClassID == 53: # FsComplexValue
            get_feat_abbr_list(spec.ValueOA.FeatureSpecsOC, feat_abbr_list)
        else: # FsClosedValue - I don't think the other types are in use
            
            featGrpName = ITsString(spec.FeatureRA.Name.BestAnalysisAlternative).Text
            abbValue = ITsString(spec.ValueRA.Abbreviation.BestAnalysisAlternative).Text
            feat_abbr_list.append((featGrpName, abbValue))
    return

def getHeadwordStr(e):
    return ITsString(e.HeadWord).Text
    
def GetEntryWithSense(e):
    # If the entry is a variant and it has no senses, loop through its references 
    # until we get to an entry that has a sense
    notDoneWithVariants = True
    while notDoneWithVariants:
        if e.SensesOS.Count == 0:
            if e.EntryRefsOS:
                foundVariant = False
                for entryRef in e.EntryRefsOS:
                    if entryRef.RefType == 0: # we have a variant
                        foundVariant = True
                        break
                if foundVariant and entryRef.ComponentLexemesRS.Count > 0:
                    # if the variant we found is a variant of sense, we are done. Use the owning entry.
                    if entryRef.ComponentLexemesRS.ToArray()[0].ClassName == 'LexSense':
                        e = entryRef.ComponentLexemesRS.ToArray()[0].OwningEntry
                        break
                    else: # normal variant of entry
                        e = entryRef.ComponentLexemesRS.ToArray()[0]
                        continue
        notDoneWithVariants = False
    return e

def GetEntryWithSensePlusFeat(e, inflFeatAbbrevs):
    # If the entry is a variant and it has no senses, loop through its references 
    # until we get to an entry that has a sense
    notDoneWithVariants = True
    while notDoneWithVariants:
        if e.SensesOS.Count == 0:
            if e.EntryRefsOS:
                foundVariant = False
                for entryRef in e.EntryRefsOS:
                    if entryRef.RefType == 0: # we have a variant
                        foundVariant = True
                        
                        # Collect any inflection features that are assigned to the special
                        # variant types called Irregularly Inflected Form
                        for varType in entryRef.VariantEntryTypesRS:
                            if varType.ClassName == "LexEntryInflType" and varType.InflFeatsOA:
                                my_feat_abbr_list = []
                                # The features might be complex, make a recursive function call to find all features
                                get_feat_abbr_list(varType.InflFeatsOA.FeatureSpecsOC, my_feat_abbr_list)
                                inflFeatAbbrevs.extend(my_feat_abbr_list)
                        break
                if foundVariant and entryRef.ComponentLexemesRS.Count > 0:
                    # if the variant we found is a variant of sense, we are done. Use the owning entry.
                    if entryRef.ComponentLexemesRS.ToArray()[0].ClassName == 'LexSense':
                        e = entryRef.ComponentLexemesRS.ToArray()[0].OwningEntry
                        break
                    else: # normal variant of entry
                        e = entryRef.ComponentLexemesRS.ToArray()[0]
                        continue
        notDoneWithVariants = False
    return e

# Convert . (dot) to _ (underscore)
def underscores(inStr):
    return re.sub(r'\.', r'_', inStr)

# This is a recursive function to get all inflection subclasses
def get_sub_inflection_classes(mySubClasses):
    
    ic_list = []
    
    for ic in mySubClasses:
        
        icAbbr = ITsString(ic.Abbreviation.BestAnalysisAlternative).Text
        icName = ITsString(ic.Name.BestAnalysisAlternative).Text
        
        ic_list.append((icAbbr,icName))
        
        if ic.SubclassesOC and len(ic.SubclassesOC.ToArray()) > 0:
            
            icl = get_sub_inflection_classes(ic.SubclassesOC)
            ic_list.extend(icl)
            
    return ic_list

def get_categories(DB, report, posMap, TargetDB=None, numCatErrorsToShow=1, addInflectionClasses=True):

    haveError = False
    dbList = [(DB, 'source')]

    # Sometimes the caller may just want source categories
    if TargetDB:
        
        dbList.append((TargetDB, 'target'))

    for dbTup in dbList:
        
        dbObj = dbTup[0]
        dbType = dbTup[1]
        
        # initialize a list of error counters to 0
        countList = [0]*len(catProbData)
            
        # loop through all database categories
        for pos in dbObj.lp.AllPartsOfSpeech:
    
            # save abbreviation and full name
            posAbbrStr = ITsString(pos.Abbreviation.BestAnalysisAlternative).Text
            posFullNameStr = pos.ToString()
            
            # check for errors or warnings, pass in the error counter list which may have been incremented
            countList, posAbbrStr = check_for_cat_errors(report, dbType, posFullNameStr, posAbbrStr, countList, numCatErrorsToShow)
            
            # add a (possibly changed abbreviation string) to the map
            add_to_cat_map(posMap, posFullNameStr, posAbbrStr)
            
            # add inflection classes to the map if there are any if we are working on the target database
            if addInflectionClasses and dbType == dbList[1][1]: #target
                
                process_inflection_classes(posMap, pos)
            
            # check for serious error
            if countList[0] == 999:
                
                # Note we have the error, but keep going so tha we give all errors at once
                # reset error (warning) counter to zero
                countList[0] = 0
                haveError = True
    
    if haveError == True:
        return True
    else:
        return False

def add_to_cat_map(posMap, posFullNameStr, posAbbrStr):
    
    # add the pos category to a map    
    if posAbbrStr not in posMap:
        
        posMap[posAbbrStr] = posFullNameStr
    else:
        # If we already have the abbreviation in the map and the full category name
        # is not the same as the source one, append the target one to the source one
        if posMap[posAbbrStr] != posFullNameStr:
            
            posMap[posAbbrStr] += ' / ' + posFullNameStr

def process_inflection_classes(posMap, pos):
    
    if pos.InflectionClassesOC and len(pos.InflectionClassesOC.ToArray()) > 0:
        
        # Get a list of abbreviation and name tuples
        AN_list = get_sub_inflection_classes(pos.InflectionClassesOC)
        
        for icAbbr, icName in AN_list:
            
            posMap[icAbbr] = icName
    
def check_for_cat_errors(report, dbType, posFullNameStr, posAbbrStr, countList, numCatErrorsToShow, myType='category'):

    haveError = False
    
    # loop through the possible invalid characters
    for i, outStrings in enumerate(catProbData):
        
        charName = outStrings[0]
        message = outStrings[1]
        replChar = outStrings[2]
        invalidCharCompiledRE = outStrings[3]
        
        # give a warning if we find an invalid character
        if invalidCharCompiledRE.search(posAbbrStr):
            
            # check for a fatal error
            if message == 'fatal':
                
                if report:
                    report.Error(f"The abbreviation: '{posAbbrStr}' for {myType}: '{posFullNameStr}' can't have a {charName} in it. Could not complete, please correct this {myType} in the {dbType} database.")
                haveError = True
                
                # show all fatal errors
                continue
            
            oldAbbrStr = posAbbrStr
            
            # do the conversion    
            posAbbrStr = invalidCharCompiledRE.sub(replChar, posAbbrStr)

            # If we are under the max errors to show number, give a warning
            if countList[i] < numCatErrorsToShow:
                
                if report:
                    report.Warning(f"The abbreviation: '{oldAbbrStr}' for {myType}: '{posFullNameStr}' in the {dbType} database can't have a {charName} in it. The {charName}" + \
                                   f" has been {message}, forming {posAbbrStr}. Keep this in mind when referring to this {myType} in transfer rules.")
            
            # Give suppressing message when we go 1 beyond the max
            elif countList[i] == numCatErrorsToShow:
                
                if report:
                    report.Info("Suppressing further warnings of this type.")
                
            countList[i] += 1
    
    if haveError:
        countList[0] = 999
        return countList, posAbbrStr
    
    return countList, posAbbrStr
